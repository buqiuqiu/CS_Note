#include <string>

std::string formatSI(size_t n);
std::string formatIEC(size_t n);
