package bankqueue.customer;

public enum CustomerType {
    kNormal, kFast, kVip
}
